<?php
namespace src;

class Config {
    const BASE_DIR = '/questoesconcurso/public';

    const DB_DRIVER = 'mysql';
    const DB_HOST = '31.170.166.166';
    const DB_DATABASE = 'u893640490_questoes';
    CONST DB_USER = 'u893640490_questoes';
    const DB_PASS = 'Teste123';

    const ERROR_CONTROLLER = 'ErrorController';
    const DEFAULT_ACTION = 'index';
}