<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?=$base?>/assets/style.css">
    <script src="https://kit.fontawesome.com/adc9de9a21.js" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
    
<div class="cabecalho">
    <div><h2>Meu Desempenho <?=$titulo;?></h2></div>
</div>